# licando
food app for Swazi Mobile
